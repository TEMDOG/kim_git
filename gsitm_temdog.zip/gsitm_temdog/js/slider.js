var i = 0;
window.onload=function(){
    slider();
}

function slider() {
    var a;
    var b = document.getElementsByClassName("slider_item");

    for (a=0; a<b.length; a++){
        b[a].style.display = "none";
    }
    i++;
    if (i > b.length){
        i=1;
    }
    b[i-1].style.display="block";
    setTimeout(slider,3000);
}